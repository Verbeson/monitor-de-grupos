// Popup de configuracao da extensao
document.addEventListener("DOMContentLoaded", () => {
  const grupoList = document.getElementById("grupoList");
  const grupoInput = document.getElementById("grupoInput");
  const grupoAddBtn = document.getElementById("grupoAddBtn");
  const numList = document.getElementById("numList");
  const numInput = document.getElementById("numInput");
  const numAddBtn = document.getElementById("numAddBtn");
  const palavraList = document.getElementById("palavraList");
  const palavraInput = document.getElementById("palavraInput");
  const palavraAddBtn = document.getElementById("palavraAddBtn");
  const toggleAtivo = document.getElementById("toggleAtivo");
  const openWA = document.getElementById("openWA");
  const statusPanel = document.getElementById("statusPanel");
  const statusIcon = document.getElementById("statusIcon");
  const statusText = document.getElementById("statusText");

  let config = {
    gruposFiltros: ["MONITORAMENTO"],
    numerosIgnorados: [],
    palavrasIgnoradas: [],
    ativo: true,
  };

  // Carregar config
  function loadConfig() {
    chrome.storage.local.get(
      {
        gruposFiltros: ["MONITORAMENTO"],
        numerosIgnorados: [],
        palavrasIgnoradas: [],
        ativo: true,
      },
      (data) => {
        config = data;
        toggleAtivo.checked = config.ativo;
        renderGrupos();
        renderNumeros();
        renderPalavras();
      }
    );
  }

  // Salvar config
  function saveConfig() {
    chrome.storage.local.set({
      gruposFiltros: config.gruposFiltros,
      numerosIgnorados: config.numerosIgnorados,
      palavrasIgnoradas: config.palavrasIgnoradas,
      ativo: config.ativo,
    });
  }

  // Renderizar lista de grupos
  function renderGrupos() {
    grupoList.innerHTML = "";
    if (config.gruposFiltros.length === 0) {
      grupoList.innerHTML = '<li class="empty">Nenhum grupo configurado</li>';
      return;
    }
    config.gruposFiltros.forEach((g, i) => {
      const li = document.createElement("li");
      li.innerHTML = `
        <span>${escapeHtml(g)}</span>
        <button class="btn btn-remove btn-small" data-idx="${i}">X</button>
      `;
      li.querySelector("button").addEventListener("click", () => {
        config.gruposFiltros.splice(i, 1);
        saveConfig();
        renderGrupos();
      });
      grupoList.appendChild(li);
    });
  }

  // Renderizar lista de contatos ignorados
  function renderNumeros() {
    numList.innerHTML = "";
    if (config.numerosIgnorados.length === 0) {
      numList.innerHTML = '<li class="empty">Nenhum contato ignorado</li>';
      return;
    }
    config.numerosIgnorados.forEach((item, i) => {
      const num = typeof item === "string" ? item : item.numero;
      const ativo = typeof item === "string" ? true : item.ativo !== false;
      const li = document.createElement("li");
      li.innerHTML = `
        <span>${escapeHtml(num)}</span>
        <span>
          <span class="badge-ativo ${ativo ? "on" : "off"}">${ativo ? "ATIVO" : "INATIVO"}</span>
          <button class="btn btn-toggle btn-small" data-idx="${i}" title="Ativar/Desativar">&#x21C5;</button>
          <button class="btn btn-remove btn-small" data-idx="${i}" title="Remover">X</button>
        </span>
      `;
      li.querySelectorAll("button")[0].addEventListener("click", () => {
        if (typeof config.numerosIgnorados[i] === "string") {
          config.numerosIgnorados[i] = { numero: config.numerosIgnorados[i], ativo: false };
        } else {
          config.numerosIgnorados[i].ativo = !config.numerosIgnorados[i].ativo;
        }
        saveConfig();
        renderNumeros();
      });
      li.querySelectorAll("button")[1].addEventListener("click", () => {
        config.numerosIgnorados.splice(i, 1);
        saveConfig();
        renderNumeros();
      });
      numList.appendChild(li);
    });
  }

  // Renderizar lista de palavras ignoradas
  function renderPalavras() {
    palavraList.innerHTML = "";
    if (config.palavrasIgnoradas.length === 0) {
      palavraList.innerHTML = '<li class="empty">Nenhuma palavra configurada</li>';
      return;
    }
    config.palavrasIgnoradas.forEach((p, i) => {
      const li = document.createElement("li");
      li.innerHTML = `
        <span>${escapeHtml(p)}</span>
        <button class="btn btn-remove btn-small" data-idx="${i}">X</button>
      `;
      li.querySelector("button").addEventListener("click", () => {
        config.palavrasIgnoradas.splice(i, 1);
        saveConfig();
        renderPalavras();
      });
      palavraList.appendChild(li);
    });
  }

  // Adicionar grupo
  grupoAddBtn.addEventListener("click", () => {
    const val = grupoInput.value.trim();
    if (val && !config.gruposFiltros.includes(val)) {
      config.gruposFiltros.push(val);
      saveConfig();
      renderGrupos();
      grupoInput.value = "";
    }
  });

  grupoInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") grupoAddBtn.click();
  });

  // Adicionar contato ignorado (nome ou numero)
  numAddBtn.addEventListener("click", () => {
    const val = numInput.value.trim();
    if (!val) return;
    const exists = config.numerosIgnorados.some((item) => {
      const num = typeof item === "string" ? item : item.numero;
      return num.toLowerCase() === val.toLowerCase();
    });
    if (!exists) {
      config.numerosIgnorados.push({ numero: val, ativo: true });
      saveConfig();
      renderNumeros();
      numInput.value = "";
    }
  });

  numInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") numAddBtn.click();
  });

  // Adicionar palavra ignorada
  palavraAddBtn.addEventListener("click", () => {
    const val = palavraInput.value.trim();
    if (!val) return;
    const exists = config.palavrasIgnoradas.some((p) => p.toLowerCase() === val.toLowerCase());
    if (!exists) {
      config.palavrasIgnoradas.push(val);
      saveConfig();
      renderPalavras();
      palavraInput.value = "";
    }
  });

  palavraInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") palavraAddBtn.click();
  });

  // Toggle monitoramento
  toggleAtivo.addEventListener("change", () => {
    config.ativo = toggleAtivo.checked;
    saveConfig();
  });

  // Abrir WhatsApp Web
  openWA.addEventListener("click", () => {
    chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, (tabs) => {
      if (tabs.length > 0) {
        chrome.tabs.update(tabs[0].id, { active: true });
        chrome.windows.update(tabs[0].windowId, { focused: true });
      } else {
        chrome.tabs.create({ url: "https://web.whatsapp.com" });
      }
    });
  });

  // Verificar status da conexao
  function checkStatus() {
    chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, (tabs) => {
      if (tabs.length > 0) {
        statusPanel.className = "status-panel conectado";
        statusIcon.textContent = "\u2705";
        statusText.textContent = "WhatsApp Web aberto";
        statusText.className = "status-text conectado";
      } else {
        statusPanel.className = "status-panel desconectado";
        statusIcon.textContent = "\u274C";
        statusText.textContent = "WhatsApp Web nao esta aberto";
        statusText.className = "status-text desconectado";
      }
    });
  }

  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  // Inicializar
  loadConfig();
  checkStatus();
});
