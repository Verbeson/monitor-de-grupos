// Popup de configuracao da extensao
document.addEventListener("DOMContentLoaded", () => {
  const grupoList = document.getElementById("grupoList");
  const grupoInput = document.getElementById("grupoInput");
  const grupoAddBtn = document.getElementById("grupoAddBtn");
  const grupoInputRow = document.getElementById("grupoInputRow");
  const grupoLimit = document.getElementById("grupoLimit");
  const numList = document.getElementById("numList");
  const numInput = document.getElementById("numInput");
  const numAddBtn = document.getElementById("numAddBtn");
  const numInputRow = document.getElementById("numInputRow");
  const numLimit = document.getElementById("numLimit");
  const palavraList = document.getElementById("palavraList");
  const palavraInput = document.getElementById("palavraInput");
  const palavraAddBtn = document.getElementById("palavraAddBtn");
  const palavraInputRow = document.getElementById("palavraInputRow");
  const palavraLimit = document.getElementById("palavraLimit");
  const toggleAtivo = document.getElementById("toggleAtivo");
  const openWA = document.getElementById("openWA");
  const statusPanel = document.getElementById("statusPanel");
  const statusIcon = document.getElementById("statusIcon");
  const statusText = document.getElementById("statusText");
  const planBadge = document.getElementById("planBadge");
  const licenseKey = document.getElementById("licenseKey");
  const activateBtn = document.getElementById("activateBtn");
  const keyError = document.getElementById("keyError");
  const keySuccess = document.getElementById("keySuccess");
  const proStatus = document.getElementById("proStatus");
  const proActivation = document.getElementById("proActivation");
  const proActive = document.getElementById("proActive");
  const proSection = document.getElementById("proSection");
  const deactivateBtn = document.getElementById("deactivateBtn");

  const FREE_LIMIT = 1;

  let config = {
    gruposFiltros: ["MONITORAMENTO"],
    numerosIgnorados: [],
    palavrasIgnoradas: [],
    ativo: true,
  };

  let isPro = false;
  let proExpiry = ""; // "AAMM" da chave

  // Validar chave de licenca
  // Formato: MGP-AAMM-XXXX-XXXX (AAMM = ano/mes de expiracao)
  function validateKey(key) {
    if (!key) return { valid: false };
    key = key.trim().toUpperCase();
    if (!/^MGP-[0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(key)) return { valid: false };

    // Extrair data de expiracao
    var datePart = key.substring(4, 8); // AAMM
    var year = parseInt(datePart.substring(0, 2), 10);
    var month = parseInt(datePart.substring(2, 4), 10);
    if (month < 1 || month > 12 || year < 24) return { valid: false };

    // Checksum: soma dos charCodes dos blocos 2 e 3 divisivel por 7
    var checkPart = key.substring(9).replace(/-/g, ""); // 8 chars dos blocos 2 e 3
    var sum = 0;
    for (var i = 0; i < checkPart.length; i++) {
      sum += checkPart.charCodeAt(i);
    }
    if (sum % 7 !== 0) return { valid: false };

    // Verificar se esta dentro da validade (valida ate o ultimo dia do mes)
    var now = new Date();
    var expiryYear = 2000 + year;
    var expiryMonth = month; // 1-based
    // Ultimo dia do mes de expiracao
    var expiryDate = new Date(expiryYear, expiryMonth, 0, 23, 59, 59);

    if (now > expiryDate) {
      return { valid: true, expired: true, expiry: datePart };
    }

    return { valid: true, expired: false, expiry: datePart };
  }

  function formatExpiry(aamm) {
    if (!aamm || aamm.length !== 4) return "";
    var meses = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
    var month = parseInt(aamm.substring(2, 4), 10);
    var year = parseInt(aamm.substring(0, 2), 10);
    return meses[month - 1] + "/20" + (year < 10 ? "0" + year : year);
  }

  // Carregar plano
  function loadPlan() {
    chrome.storage.local.get({ licenseKey: "" }, (data) => {
      if (data.licenseKey) {
        var result = validateKey(data.licenseKey);
        if (result.valid && !result.expired) {
          isPro = true;
          proExpiry = result.expiry;
        } else if (result.valid && result.expired) {
          // Chave valida mas expirada
          isPro = false;
          proExpiry = result.expiry;
        } else {
          isPro = false;
          proExpiry = "";
        }
      } else {
        isPro = false;
        proExpiry = "";
      }
      updatePlanUI();
    });
  }

  // Atualizar UI conforme plano
  function updatePlanUI() {
    if (isPro) {
      planBadge.textContent = "PRO";
      planBadge.className = "plan-badge pro";
      proStatus.style.display = "";
      proStatus.textContent = "Ativo ate " + formatExpiry(proExpiry);
      proActivation.style.display = "none";
      proActive.style.display = "";
      proSection.className = "pro-section active";
    } else {
      if (proExpiry) {
        // Chave expirada
        planBadge.textContent = "EXPIRADO";
        planBadge.className = "plan-badge free";
        keyError.style.display = "";
        keyError.textContent = "Sua chave expirou em " + formatExpiry(proExpiry) + ". Renove para continuar usando o Pro.";
      } else {
        planBadge.textContent = "FREE";
        planBadge.className = "plan-badge free";
        keyError.style.display = "none";
      }
      proStatus.style.display = "none";
      proActivation.style.display = "";
      proActive.style.display = "none";
      proSection.className = "pro-section";
    }
    updateLimits();
  }

  // Atualizar visibilidade dos inputs conforme limites
  function updateLimits() {
    if (isPro) {
      grupoInputRow.style.display = "";
      grupoLimit.style.display = "none";
      numInputRow.style.display = "";
      numLimit.style.display = "none";
      palavraInputRow.style.display = "";
      palavraLimit.style.display = "none";
    } else {
      var grupoAtLimit = config.gruposFiltros.length >= FREE_LIMIT;
      grupoInputRow.style.display = grupoAtLimit ? "none" : "";
      grupoLimit.style.display = grupoAtLimit ? "" : "none";

      var numAtLimit = config.numerosIgnorados.length >= FREE_LIMIT;
      numInputRow.style.display = numAtLimit ? "none" : "";
      numLimit.style.display = numAtLimit ? "" : "none";

      var palavraAtLimit = config.palavrasIgnoradas.length >= FREE_LIMIT;
      palavraInputRow.style.display = palavraAtLimit ? "none" : "";
      palavraLimit.style.display = palavraAtLimit ? "" : "none";
    }
  }

  // Scroll para secao Pro
  function scrollToProSection() {
    proSection.scrollIntoView({ behavior: "smooth" });
    licenseKey.focus();
  }

  document.getElementById("grupoUpgrade").addEventListener("click", scrollToProSection);
  document.getElementById("numUpgrade").addEventListener("click", scrollToProSection);
  document.getElementById("palavraUpgrade").addEventListener("click", scrollToProSection);

  // Ativar Pro
  activateBtn.addEventListener("click", () => {
    var key = licenseKey.value.trim().toUpperCase();
    keyError.style.display = "none";
    keySuccess.style.display = "none";
    var result = validateKey(key);
    if (result.valid && !result.expired) {
      chrome.storage.local.set({ licenseKey: key });
      isPro = true;
      proExpiry = result.expiry;
      keySuccess.style.display = "";
      keySuccess.textContent = "Plano Pro ativado! Valido ate " + formatExpiry(proExpiry) + ".";
      updatePlanUI();
    } else if (result.valid && result.expired) {
      keyError.style.display = "";
      keyError.textContent = "Esta chave expirou em " + formatExpiry(result.expiry) + ". Adquira uma nova chave.";
    } else {
      keyError.style.display = "";
      keyError.textContent = "Chave invalida. Verifique e tente novamente.";
    }
  });

  licenseKey.addEventListener("keydown", (e) => {
    if (e.key === "Enter") activateBtn.click();
  });

  // Desativar Pro
  deactivateBtn.addEventListener("click", () => {
    chrome.storage.local.remove("licenseKey");
    isPro = false;
    licenseKey.value = "";
    keySuccess.style.display = "none";
    updatePlanUI();
  });

  // Carregar config
  function loadConfig() {
    chrome.storage.local.get(
      {
        gruposFiltros: ["MONITORAMENTO"],
        numerosIgnorados: [],
        palavrasIgnoradas: [],
        ativo: true,
      },
      (data) => {
        config = data;
        toggleAtivo.checked = config.ativo;
        renderGrupos();
        renderNumeros();
        renderPalavras();
        updateLimits();
      }
    );
  }

  // Salvar config
  function saveConfig() {
    chrome.storage.local.set({
      gruposFiltros: config.gruposFiltros,
      numerosIgnorados: config.numerosIgnorados,
      palavrasIgnoradas: config.palavrasIgnoradas,
      ativo: config.ativo,
    });
  }

  // Renderizar lista de grupos
  function renderGrupos() {
    grupoList.innerHTML = "";
    if (config.gruposFiltros.length === 0) {
      grupoList.innerHTML = '<li class="empty">Nenhum grupo configurado</li>';
      return;
    }
    config.gruposFiltros.forEach((g, i) => {
      const li = document.createElement("li");
      li.innerHTML = `
        <span>${escapeHtml(g)}</span>
        <button class="btn btn-remove btn-small" data-idx="${i}">X</button>
      `;
      li.querySelector("button").addEventListener("click", () => {
        config.gruposFiltros.splice(i, 1);
        saveConfig();
        renderGrupos();
        updateLimits();
      });
      grupoList.appendChild(li);
    });
  }

  // Renderizar lista de contatos ignorados
  function renderNumeros() {
    numList.innerHTML = "";
    if (config.numerosIgnorados.length === 0) {
      numList.innerHTML = '<li class="empty">Nenhum contato ignorado</li>';
      return;
    }
    config.numerosIgnorados.forEach((item, i) => {
      const num = typeof item === "string" ? item : item.numero;
      const ativo = typeof item === "string" ? true : item.ativo !== false;
      const li = document.createElement("li");
      li.innerHTML = `
        <span>${escapeHtml(num)}</span>
        <span>
          <span class="badge-ativo ${ativo ? "on" : "off"}">${ativo ? "ATIVO" : "INATIVO"}</span>
          <button class="btn btn-toggle btn-small" data-idx="${i}" title="Ativar/Desativar">&#x21C5;</button>
          <button class="btn btn-remove btn-small" data-idx="${i}" title="Remover">X</button>
        </span>
      `;
      li.querySelectorAll("button")[0].addEventListener("click", () => {
        if (typeof config.numerosIgnorados[i] === "string") {
          config.numerosIgnorados[i] = { numero: config.numerosIgnorados[i], ativo: false };
        } else {
          config.numerosIgnorados[i].ativo = !config.numerosIgnorados[i].ativo;
        }
        saveConfig();
        renderNumeros();
      });
      li.querySelectorAll("button")[1].addEventListener("click", () => {
        config.numerosIgnorados.splice(i, 1);
        saveConfig();
        renderNumeros();
        updateLimits();
      });
      numList.appendChild(li);
    });
  }

  // Renderizar lista de palavras ignoradas
  function renderPalavras() {
    palavraList.innerHTML = "";
    if (config.palavrasIgnoradas.length === 0) {
      palavraList.innerHTML = '<li class="empty">Nenhuma palavra configurada</li>';
      return;
    }
    config.palavrasIgnoradas.forEach((p, i) => {
      const li = document.createElement("li");
      li.innerHTML = `
        <span>${escapeHtml(p)}</span>
        <button class="btn btn-remove btn-small" data-idx="${i}">X</button>
      `;
      li.querySelector("button").addEventListener("click", () => {
        config.palavrasIgnoradas.splice(i, 1);
        saveConfig();
        renderPalavras();
        updateLimits();
      });
      palavraList.appendChild(li);
    });
  }

  // Adicionar grupo
  grupoAddBtn.addEventListener("click", () => {
    if (!isPro && config.gruposFiltros.length >= FREE_LIMIT) return;
    const val = grupoInput.value.trim();
    if (val && !config.gruposFiltros.includes(val)) {
      config.gruposFiltros.push(val);
      saveConfig();
      renderGrupos();
      grupoInput.value = "";
      updateLimits();
    }
  });

  grupoInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") grupoAddBtn.click();
  });

  // Adicionar contato ignorado (nome ou numero)
  numAddBtn.addEventListener("click", () => {
    if (!isPro && config.numerosIgnorados.length >= FREE_LIMIT) return;
    const val = numInput.value.trim();
    if (!val) return;
    const exists = config.numerosIgnorados.some((item) => {
      const num = typeof item === "string" ? item : item.numero;
      return num.toLowerCase() === val.toLowerCase();
    });
    if (!exists) {
      config.numerosIgnorados.push({ numero: val, ativo: true });
      saveConfig();
      renderNumeros();
      numInput.value = "";
      updateLimits();
    }
  });

  numInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") numAddBtn.click();
  });

  // Adicionar palavra ignorada
  palavraAddBtn.addEventListener("click", () => {
    if (!isPro && config.palavrasIgnoradas.length >= FREE_LIMIT) return;
    const val = palavraInput.value.trim();
    if (!val) return;
    const exists = config.palavrasIgnoradas.some((p) => p.toLowerCase() === val.toLowerCase());
    if (!exists) {
      config.palavrasIgnoradas.push(val);
      saveConfig();
      renderPalavras();
      palavraInput.value = "";
      updateLimits();
    }
  });

  palavraInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") palavraAddBtn.click();
  });

  // Toggle monitoramento
  toggleAtivo.addEventListener("change", () => {
    config.ativo = toggleAtivo.checked;
    saveConfig();
  });

  // Abrir WhatsApp Web
  openWA.addEventListener("click", () => {
    chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, (tabs) => {
      if (tabs.length > 0) {
        chrome.tabs.update(tabs[0].id, { active: true });
        chrome.windows.update(tabs[0].windowId, { focused: true });
      } else {
        chrome.tabs.create({ url: "https://web.whatsapp.com" });
      }
    });
  });

  // Verificar status da conexao
  function checkStatus() {
    chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, (tabs) => {
      if (tabs.length > 0) {
        statusPanel.className = "status-panel conectado";
        statusIcon.textContent = "\u2705";
        statusText.textContent = "WhatsApp Web aberto";
        statusText.className = "status-text conectado";
      } else {
        statusPanel.className = "status-panel desconectado";
        statusIcon.textContent = "\u274C";
        statusText.textContent = "WhatsApp Web nao esta aberto";
        statusText.className = "status-text desconectado";
      }
    });
  }

  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  // Inicializar
  loadPlan();
  loadConfig();
  checkStatus();
});
